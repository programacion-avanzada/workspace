import java.util.ArrayList;

public class Grafo {

	int cantNodos;
	int[][] ady;
	private ArrayList<Nodo> listaNodos;
	public final static int INFINITE = Integer.MAX_VALUE;
	
	public Grafo(int can) {
		this.cantNodos = can;
		this.ady = new int[can][can];
		this.listaNodos = new ArrayList<Nodo>();
	}
	
	public void agregarNodo(Nodo n ) {
		this.listaNodos.add(n);
		
	}

	public void agregarPeso(int nodoIni, int nodoFin, int peso) {
		this.ady[nodoIni][nodoFin] = this.ady[nodoFin][nodoIni] = peso;
	}

	public int getCantNodos() {
		// TODO Auto-generated method stub
		return this.cantNodos;
	}

	public int getDistNodo(int i, int j) {
		return this.ady[i][j];
	}

	public ArrayList<Nodo> getListaNodos() {
		return this.listaNodos;
	}

	public int[][] getMatrizAdy() {
		// TODO Auto-generated method stub
		return this.ady;
	}

}
