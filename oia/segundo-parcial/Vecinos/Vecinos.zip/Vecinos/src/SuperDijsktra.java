

public class SuperDijsktra {

	private Grafo g;
	public SuperDijsktra(Grafo g) {
		this.g = g;
	}

	public int[] resolver(int nodoIni,int nodoF) {
		int cantNodos = g.getCantNodos();
		boolean[] nodosVisitados = new boolean[cantNodos];
		int[] d = new int[cantNodos]; //Representa la fuerza de amistad con todos los nodos.
		//las posiciones i-esimas con valor cero, hace referencia al nodo contrincante o nodos que no
		//pueden ser alcanzados por el nodo inicial porque no los conecta con ninguno
		int [][] C = this.g.getMatrizAdy();
		
		for (int i = 0; i < cantNodos; i++) {
			d[i] = C[nodoIni][i];	
		}
		
		int w = nodoIni;
		
		for (int j = 0; j < cantNodos - 1; j++) {
			nodosVisitados[w] = true;
			int pesoAmistad = 0;
			for (int i = 0; i < cantNodos; i++) {
				pesoAmistad = 0;
				if (w != i && w != nodoF && i != nodoIni && w != nodoIni && i != nodoF) {
					//El nodo que estoy analizando no es ni inicial ni final ni es el mismo al i (no puede evaluarse a si mismo)
					pesoAmistad = d[w]; // Fuerza de Amistad del nodo que estoy parado analizando sus adyacentes
					
					if (C[w][i] < pesoAmistad && C[w][i] != 0) {
						//El lazo que une nodo w con i es menor a la fuerza
						//De amistad, por lo tanto la nueva fuerza es el nuevo eslabon
						pesoAmistad = C[w][i];
					}
					if (C[w][i] != 0) {
						//Existe conexion con nodo w e i
						if (d[i] < pesoAmistad) {
							//la fuerza de amistad de nodo inicial a i es menor a la nueva cadena
							//reemplazo la nueva cadena en el nodo porque tiene mayor fuerza y sigo.
							d[i] = pesoAmistad;
						}
					}
				}
			}
			w = buscarW(d, nodosVisitados); 
			// Me devuelve el w con mayor fuerza de amistad 
			//para poder recorrer primero las aristas mayores y descartar directamente las cadenas menores	
			//Ademas siempre va a devolver un nodo w que no esta visitado.
		}
		return d;
	}

	private int buscarW(int[] dAux, boolean[] nodosVisitados) {
		int min = -1, w = 0;

		for (int i = 0; i < dAux.length; i++) {

			if (!nodosVisitados[i]) {
				if (min == -1) {
					min = dAux[i];
					w = i;
				}
				if (min != 0 && dAux[i] != 0 && min < dAux[i]) {
					min = dAux[i];
					w = i;
				} else if (min == 0 && dAux[i] != 0) {
					min = dAux[i];
					w = i;

				}
			}
		}

		return w;
	}

	public static void main(String[] args) {
		Grafo g = new Grafo(7);
		//Caso probado con ciclos en clase FUNCIONA! 
		//con varios vecinos contrincantes (hay que seguir probando)
		
		/*
		g.agregarPeso(0, 1, 30);
		g.agregarPeso(1, 3, 15);
		g.agregarPeso(3, 4, 10);
		g.agregarPeso(2, 4, 30);
		g.agregarPeso(1, 2, 25);
		g.agregarPeso(5, 4, 30);
		*/
		
		//Caso del enunciado 
		g.agregarPeso(0, 1, 29);
		g.agregarPeso(0, 3, 6);
		g.agregarPeso(0, 2, 12);
		g.agregarPeso(0, 5, 2);
		
		g.agregarPeso(2, 1, 9);
		g.agregarPeso(2, 6, 98);
		g.agregarPeso(2, 4, 7);
		
		g.agregarPeso(5, 3, 78);
		g.agregarPeso(3, 4, 16);
		g.agregarPeso(4, 1, 3);
		
		SuperDijsktra d = new SuperDijsktra(g);
		int[] p = d.resolver(4,0);
		for (int i = 0; i < p.length; i++) {
			System.out.print(p[i]+"-");
		}
	}

}
